PHASE_COLORS = {
    "forming": "gold",
    "stable": "green",
    "decaying": "red",
}

PHASE_LINESTYLES = {
    "forming": {"linestyle": "solid"},
    "stable": {"linestyle": "solid"},
    "decaying": {"linestyle": "solid"},
}
