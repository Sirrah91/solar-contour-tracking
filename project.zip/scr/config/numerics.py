import numpy as np

WP = np.float32
NUM_EPS = np.finfo(WP).eps
RND_SEED = 42
